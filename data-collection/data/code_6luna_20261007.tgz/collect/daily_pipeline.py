# -*- coding: utf-8 -*-
"""일 1회 전체 수집 — K-Startup + 기업마당 → 정규화 → MySQL.

  python daily_pipeline.py                 전체 실행
  python daily_pipeline.py --dry-run       수집·정규화만. 교체와 DB 저장 안 함
  python daily_pipeline.py --skip-store    MySQL 저장 생략
  python daily_pipeline.py --force         건수 급감 경고를 무시한다
  python daily_pipeline.py --skip-attach   첨부 수집을 건너뛴다
  python daily_pipeline.py --skip-embed    임베딩을 건너뛴다
  python daily_pipeline.py --skip-upload   벡터를 공용 DB 로 올리지 않는다
  python daily_pipeline.py --skip-files    첨부 원본 파일을 올리지 않는다
  python daily_pipeline.py --skip-conditions  자격요건 추출(LLM)을 건너뛴다
  python daily_pipeline.py --skip-applicant-types  신청자 유형 추출(LLM)을 건너뛴다

기존 `daily_job.py` 는 K-Startup → `data/notices.json` 경로만 담당한다.
화면(`chat_app.py`)과 추천(`match.py`)이 아직 그 파일을 읽으므로 그대로 두고,
이 스크립트가 그 위에 기업마당·정규화·MySQL 을 얹는다.

  daily_job.run()      K-Startup 수집 · 검증 · 백업 · 원자적 교체
        ↓
  기업마당 수집          실패하면 직전 스냅샷을 그대로 쓴다
        ↓
  normalize.py         두 소스를 공통 스키마로
        ↓
  store_mysql.py       notices / notice_attachments / import_runs

**소스별로 따로 검증하고 따로 실패한다** (decisions.md D1).
합쳐서 세면 한 소스가 통째로 죽어도 전체 건수가 절반을 넘어 검증을 통과한다.
한 소스가 실패해도 나머지는 갱신하고, 실패한 소스는 직전 데이터를 유지한다.

종료 코드는 daily_job 과 맞춘다. 0 성공 / 1 실패 / 2 부분 실패 / 3 이미 실행 중
"""
import argparse
import hashlib
import json
import os
import sys
import time
from datetime import datetime, timezone

from shared import config
from collect import daily_job
from collect import job_lock
from collect import normalize

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)          # data-collection 폴더
DATA = os.path.join(ROOT, 'data')
RAW = os.path.join(DATA, 'raw')
NORM = os.path.join(DATA, 'normalized')
LOG = os.path.join(DATA, 'collect_log.jsonl')
LOCK = os.path.join(DATA, 'collection.lock')

MIN_RATIO = 0.5     # 직전 대비 이 비율 밑으로 떨어지면 교체를 막는다
KEEP_RAW = 14       # 원본 스냅샷 보관 일수 대신 개수. 소스별로 이만큼 남긴다


def stamp():
    return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')


def snapshots(source):
    """해당 소스의 원본 스냅샷을 오래된 순으로 돌려준다."""
    if not os.path.isdir(RAW):
        return []
    names = sorted(n for n in os.listdir(RAW) if n.startswith(source + '_') and n.endswith('.json'))
    return [os.path.join(RAW, n) for n in names]


def rows_in(path, source):
    """스냅샷 파일의 공고 건수. 못 읽으면 0."""
    try:
        with open(path, 'rb') as f:
            payload = json.loads(f.read().decode('utf-8-sig'))
        return len(normalize.rows_from(payload, source))
    except Exception:
        return 0


def prune(source, keep=KEEP_RAW):
    """오래된 스냅샷을 지운다. 디스크가 무한정 늘지 않게."""
    old = snapshots(source)[:-keep]
    for path in old:
        try:
            os.remove(path)
        except OSError:
            pass
    return len(old)


def collect_bizinfo(force, say):
    """기업마당 수집. (경로, 건수, 상태, 사유) 를 돌려준다.

    실패하거나 건수가 급감하면 **직전 스냅샷을 그대로 쓴다.**
    이 소스만 전일 데이터로 남고 나머지는 정상 갱신된다.
    """
    from collect import fetch_bizinfo

    previous = snapshots('bizinfo')
    prev_path = previous[-1] if previous else None
    prev_count = rows_in(prev_path, 'bizinfo') if prev_path else 0

    if not config.get('BIZINFO_KEY'):
        return prev_path, prev_count, 'skipped', 'BIZINFO_KEY 가 없다'

    try:
        path, count = fetch_bizinfo.fetch_snapshot()
    except Exception as exc:
        say('  기업마당 수집 실패: %s' % exc)
        return prev_path, prev_count, 'stale', str(exc)

    if prev_count and count < prev_count * MIN_RATIO and not force:
        # 새로 받은 것은 남기되 쓰지 않는다. 원인 확인용으로 파일은 보존한다.
        why = ('직전 %d건 → 오늘 %d건 (%.0f%% 감소)'
               % (prev_count, count, 100 * (1 - count / prev_count)))
        say('  기업마당 건수 급감으로 직전 스냅샷을 유지한다 — %s' % why)
        return prev_path, prev_count, 'rejected', why

    say('  기업마당 %d건' % count)
    return path, count, 'ok', ''


def load(path, source):
    with open(path, 'rb') as f:
        raw = f.read()
    return (json.loads(raw.decode('utf-8-sig')),
            {'source': source, 'input_file': os.path.abspath(path),
             'sha256': hashlib.sha256(raw).hexdigest()})


def build_normalized(sources, say):
    """정규화 결과를 새 파일로 쓴다. (경로, 요약) 을 돌려준다."""
    payloads, meta = [], []
    for source, path in sources:
        payload, info = load(path, source)
        payloads.append((source, payload))
        meta.append(info)

    result = normalize.normalize_sources(payloads)
    now = datetime.now(timezone.utc)
    result.update({'generated_at': now.isoformat(), 'inputs': meta})

    os.makedirs(NORM, exist_ok=True)
    out = os.path.join(NORM, 'notices_%s.json' % now.strftime('%Y%m%dT%H%M%S%fZ'))
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    s = result['summary']
    say('  정규화 %d건 (거부 %d, 소스내 중복 %d, 교차 후보 %d)'
        % (s['accepted_count'], s['rejected_count'],
           s['same_source_duplicate_count'], s['cross_source_candidate_groups']))
    return out, s


def kstartup_listed(ks):
    """오늘 새로 받았고 서버 보고 건수와 꼭 맞는 K-Startup 모집 중 목록의 공고 번호 집합. 아니면 None.

    None 이면 저장 단계가 목록에서 빠진 공고를 닫지 않는다(2026-09-30). K-Startup 수집이 실패·거부되면
    파이프라인은 어제 notices.json 을 그대로 정규화해 저장하므로, 그날 '빠졌다'는 판단을 할 수 없다.
    """
    if ks.get('status') != 'ok' or not ks.get('complete'):
        return None
    try:
        with open(daily_job.OUT, encoding='utf-8') as f:
            payload = json.load(f)
    except Exception:
        return None
    ids = {daily_job.listed_id(r) for r in payload.get('notices') or []} - {None}
    if not payload.get('complete') or not ids or len(ids) != payload.get('reported_total'):
        return None
    return ids


def store(path, say, listed=None):
    """MySQL 저장. 실패해도 예외를 올리지 않고 (성공여부, 결과) 를 돌려준다.

    listed = {출처: 오늘 모집 중 목록의 원본 ID 집합}. 주면 목록에서 빠진 open 공고를 closed 로 바꾼다.
    """
    from shared import store_mysql

    connection = None
    try:
        with open(path, 'rb') as f:
            content = f.read()
        payload = json.loads(content.decode('utf-8-sig'))
        store_mysql.validate_payload(payload)
        connection = store_mysql.connect()
        result = store_mysql.store_payload(
            connection, payload, hashlib.sha256(content).hexdigest(), listed=listed)
        say('  MySQL 저장 %s' % json.dumps(result, ensure_ascii=False)[:160])
        return True, result
    except Exception as exc:
        # 예외 원문에 SQL 값이나 접속 정보가 섞일 수 있어 종류만 남긴다.
        say('  MySQL 저장 실패: %s' % type(exc).__name__)
        return False, {'error': type(exc).__name__}
    finally:
        if connection:
            connection.close()


def write_log(entry):
    entry['run_at'] = datetime.now().isoformat(timespec='seconds')
    os.makedirs(DATA, exist_ok=True)
    with open(LOG, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry, ensure_ascii=False) + '\n')
    return entry


def run(dry_run=False, skip_store=False, force=False, say=print,
        skip_attach=False, attach_limit=None, attach_interval=1.0,
        skip_embed=False, embed_limit=None, skip_upload=False,
        skip_files=False, skip_conditions=False, conditions_limit=None,
        skip_applicant_types=False, applicant_types_limit=None, skip_judgments=False,
        skip_industries=False, industries_limit=None, skip_bonus=False, bonus_limit=None):
    try:
        with job_lock.acquire(LOCK):
            return _run(dry_run, skip_store, force, say,
                        skip_attach, attach_limit, attach_interval,
                        skip_embed, embed_limit, skip_upload, skip_files,
                        skip_conditions, conditions_limit,
                        skip_applicant_types, applicant_types_limit, skip_judgments,
                        skip_industries, industries_limit, skip_bonus, bonus_limit)
    except job_lock.JobBusy as exc:
        return {'status': 'busy', 'job': 'pipeline', 'error': str(exc)}


def _run(dry_run, skip_store, force, say,
         skip_attach=False, attach_limit=None, attach_interval=1.0,
         skip_embed=False, embed_limit=None, skip_upload=False,
         skip_files=False, skip_conditions=False, conditions_limit=None,
         skip_applicant_types=False, applicant_types_limit=None, skip_judgments=False,
         skip_industries=False, industries_limit=None, skip_bonus=False, bonus_limit=None):
    started = time.time()
    sources = {}

    # ── 1. K-Startup — 기존 경로를 그대로 쓴다 ──────────────────
    say('K-Startup 수집')
    # 잠금은 이 함수 바깥에서 이미 잡았다. daily_job.run() 을 부르면 같은 잠금을
    # 다시 잡으려다 스스로 busy 가 되므로 잠금 없는 _run() 을 직접 부른다.
    ks = daily_job._run(dry_run=dry_run, force=force, say=say)
    sources['kstartup'] = {'status': ks['status'], 'count': ks.get('count'),
                           'new_count': ks.get('new_count'), 'error': ks.get('error'),
                           'complete': ks.get('complete')}
    # ── 2. 기업마당 — 실패해도 직전 스냅샷으로 이어간다 ────────────
    say('기업마당 수집')
    biz_path, biz_count, biz_status, biz_why = collect_bizinfo(force, say)
    sources['bizinfo'] = {'status': biz_status, 'count': biz_count, 'error': biz_why or None}

    # ── 3. 정규화 ────────────────────────────────────────────
    inputs = []
    ks_path = daily_job.OUT
    if os.path.exists(ks_path):
        inputs.append(('kstartup', ks_path))
    if biz_path and os.path.exists(biz_path):
        inputs.append(('bizinfo', biz_path))

    if not inputs:
        return write_log({'status': 'error', 'job': 'pipeline', 'stage': 'normalize',
                          'error': '정규화할 입력이 없다', 'sources': sources,
                          'elapsed_sec': round(time.time() - started, 1)})

    say('정규화 (%s)' % ', '.join(s for s, _ in inputs))
    try:
        norm_path, summary = build_normalized(inputs, say)
    except Exception as exc:
        return write_log({'status': 'error', 'job': 'pipeline', 'stage': 'normalize',
                          'error': '%s: %s' % (type(exc).__name__, exc), 'sources': sources,
                          'elapsed_sec': round(time.time() - started, 1)})

    # ── 4. MySQL 저장 ───────────────────────────────────────
    stored, store_result = False, None
    if dry_run:
        say('dry-run — DB 저장을 건너뛴다')
    elif skip_store:
        say('--skip-store — DB 저장을 건너뛴다')
    else:
        say('MySQL 저장')
        # K-Startup 을 오늘 빠짐없이 받은 날에만 모집 중 목록에서 빠진 공고를 닫는다(2026-09-30)
        ks_ids = kstartup_listed(ks)
        if ks_ids is None:
            say('  K-Startup 목록을 오늘 빠짐없이 받지 못해 모집 종료 처리를 건너뛴다')
        stored, store_result = store(norm_path, say,
                                     listed={'kstartup': ks_ids} if ks_ids else None)
        if stored and store_result.get('closed_missing') is not None:
            say('  모집 중 목록에서 빠져 모집 종료로 바꾼 K-Startup 공고 %d건' % store_result['closed_missing'])

    # ── 5. 첨부 받기·본문 추출 ────────────────────────────────
    # 공고 저장이 끝난 뒤에 한다. 여기서 실패해도 공고 데이터는 이미 최신이다.
    attach = None
    if stored and not skip_attach:
        say('첨부 수집')
        try:
            from collect import attachment_pipeline
            attach, _ = attachment_pipeline.daily(
                limit=attach_limit, interval=attach_interval,
                say=lambda line: say('  ' + line))
        except Exception as exc:
            say('  첨부 수집 실패: %s' % type(exc).__name__)
            attach = {'error': '%s: %s' % (type(exc).__name__, str(exc)[:200])}
    elif skip_attach:
        say('--skip-attach — 첨부 수집을 건너뛴다')

    # ── 6·7. 임베딩 생성 → 벡터 색인 갱신 ─────────────────────
    # 벡터가 없거나 내용이 바뀐 공고만 만든다. 보통 하루 수십 건이다.
    # 여기서 실패해도 1~5 단계는 이미 끝나 있다.
    embed_result = None
    if stored and not skip_embed:
        say('임베딩')
        try:
            from shared import embed
            from search import vecstore
            embed_result = embed.run(limit=embed_limit,
                                     say=lambda line: say('  ' + line))
            changed = embed_result.get('changed_ids')
            if embed_result.get('made') or changed is None:
                say('벡터 색인')
                embed_result['index'] = vecstore.sync(
                    changed_ids=changed, say=lambda line: say('  ' + line))
        except Exception as exc:
            say('  임베딩 실패: %s' % type(exc).__name__)
            embed_result = {'error': '%s: %s' % (type(exc).__name__, str(exc)[:200])}
    elif skip_embed:
        say('--skip-embed — 임베딩을 건너뛴다')

    # ── 8. 벡터를 공용 MySQL 로 올리기 ────────────────────────
    # 6단계가 만든 벡터는 이 PC 에만 있다. 팀이 쓰려면 DB 로 올려야 한다.
    # 올릴 것은 DB 와 npz 를 대조해 스스로 고른다. 그래서 임베딩이 실패하거나
    # 건너뛴 날에도, 지난번에 못 올린 것이 있으면 여기서 따라잡는다.
    upload_result = None
    if stored and not skip_upload:
        say('벡터 업로드')
        try:
            from collect import upload_vectors
            upload_result = upload_vectors.run(say=lambda line: say('  ' + line))
        except Exception as exc:
            say('  벡터 업로드 실패: %s' % type(exc).__name__)
            upload_result = {'error': '%s: %s' % (type(exc).__name__, str(exc)[:200])}
    elif skip_upload:
        say('--skip-upload — 벡터 업로드를 건너뛴다')

    # ── 9. 첨부 원본 파일을 공용 MySQL 로 ─────────────────────
    # 팀원이 파일 자체를 개발에 쓸 수 있게 올린다. 해시가 곧 내용이라
    # 이미 있는 것은 건너뛴다. 첫 실행만 620MB 이고 그 뒤로는 그날 받은 것뿐이다.
    file_result = None
    if stored and not skip_files:
        say('첨부 파일 업로드')
        try:
            from collect import upload_attachments
            file_result = upload_attachments.run(say=lambda line: say('  ' + line))
        except Exception as exc:
            say('  첨부 파일 업로드 실패: %s' % type(exc).__name__)
            file_result = {'error': '%s: %s' % (type(exc).__name__, str(exc)[:200])}
    elif skip_files:
        say('--skip-files — 첨부 파일 업로드를 건너뛴다')

    # ── 10. 첨부 본문에서 자격요건 뽑기 (LLM) ──────────────────
    # 5단계가 첨부 본문을 채운 뒤에 와야 한다. 지원금액·사업자 형태처럼
    # API 가 주지 않는 값을 공고문에서 뽑아 notice_conditions 에 넣는다.
    #
    # **바뀐 것만 부른다.** 문서 해시(input_sha256)가 같으면 건너뛰므로
    # 하루 비용은 신규 공고 수십 건 분량이다. 최초 1,542건이 약 $1 이었다.
    #
    # 실패해도 1~9단계는 이미 끝나 있다. 다음 실행이 못 뽑은 것을 다시 고른다.
    conditions_result = None
    if stored and not skip_conditions:
        say('자격요건 추출')
        try:
            from collect import extract_conditions
            conditions_result = extract_conditions.run_batch(
                limit=conditions_limit, say=lambda line: say('  ' + line))
        except Exception as exc:
            say('  자격요건 추출 실패: %s' % type(exc).__name__)
            conditions_result = {'error': '%s: %s' % (type(exc).__name__, str(exc)[:200])}
    elif skip_conditions:
        say('--skip-conditions — 자격요건 추출을 건너뛴다')

    # ── 11. 신청자 유형 뽑기 (LLM, 2026-09-28) ─────────────────
    # 매칭·자격 확인이 쓰는 예비창업자·개인사업자·법인 판정(search/applicant_types.py). 공고문 발췌 해시가 같으면
    # 건너뛰므로 새 공고·바뀐 공고만 부른다. 하루 상한 300건(약 $0.25). 결과는 data/applicant_types/ 에만 쓴다(DB 쓰기 없음).
    # 실패해도 1~10단계는 이미 끝나 있다. 다음 실행이 못 뽑은 것을 다시 고른다.
    applicant_types_result = None
    if stored and not skip_applicant_types:
        say('신청자 유형 추출')
        try:
            from collect import applicant_type_daily
            applicant_types_result = applicant_type_daily.run_batch(
                limit=applicant_types_limit, say=lambda line: say('  ' + line))
        except Exception as exc:
            say('  신청자 유형 추출 실패: %s' % type(exc).__name__)
            applicant_types_result = {'error': '%s: %s' % (type(exc).__name__, str(exc)[:200])}
    elif skip_applicant_types:
        say('--skip-applicant-types — 신청자 유형 추출을 건너뛴다')

    # ── 12. 업종 뽑기 (LLM, 2026-09-28) ──────────────────────
    # 새 공고·바뀐 공고의 신청 가능 업종(collect/industry_daily.py). 11단계와 같은 방식 — 문서 해시가 같으면 건너뛰고,
    # 날짜당 상한 300건(약 $0.35), 같은 문서로 3번 실패하면 멈춘다. 결과는 data/industries/ 에만 쓴다(13단계가 올린다)
    industries_result = None
    if stored and not skip_industries:
        say('업종 추출')
        try:
            from collect import industry_daily
            industries_result = industry_daily.run_batch(
                limit=industries_limit, say=lambda line: say('  ' + line))
        except Exception as exc:
            say('  업종 추출 실패: %s' % type(exc).__name__)
            industries_result = {'error': '%s: %s' % (type(exc).__name__, str(exc)[:200])}
    elif skip_industries:
        say('--skip-industries — 업종 추출을 건너뛴다')

    # ── 13. 공고 판정을 공용 DB 로 올리기 (2026-09-28) ─────────
    # 신청자 유형(11단계 누적 파일)·업종 판정을 notice_applicant_types·notice_industries 로 올린다.
    # 8단계 벡터 올리기와 같다 — 바뀐 행만 UPSERT, 팀원·EC2 가 SQL 로 읽는다(docs/guides/JUDGMENT_TABLES.md).
    # 첫 업로드는 2026-09-28 사용자 확인 뒤 손으로 했다(4,952행). --skip-upload 도 따른다(공용 DB 로 올리지 않음)
    judgments_result = None
    if stored and not skip_judgments and not skip_upload:
        say('판정 올리기')
        try:
            from collect import upload_judgments
            parts = upload_judgments.run(say=lambda line: say('  ' + line))
            errors = ['%s: %s' % (k, v['error']) for k, v in parts.items() if v.get('error')]
            # 파일이 크게 줄었다는 경고(2026-09-29 — 올리기는 막지 않는다)도 stage_warnings 로 남긴다
            warnings = ['%s: %s' % (k, v['warning']) for k, v in parts.items() if v.get('warning')]
            judgments_result = dict(parts, error='; '.join(errors) or None, warning='; '.join(warnings) or None)
        except Exception as exc:
            say('  판정 올리기 실패: %s' % type(exc).__name__)
            judgments_result = {'error': '%s: %s' % (type(exc).__name__, str(exc)[:200])}
    elif skip_judgments or skip_upload:
        say('판정 올리기를 건너뛴다(--skip-judgments 또는 --skip-upload)')

    # ── 14. 공고 가점 뽑기 (LLM, 2026-10-06, docs/notice_api/03_bonus) ──
    # 조율 창구의 신청자별 가산점이 쓰는 공고 가점(collect/extract_bonus.py → 공용 DB notice_bonus). 열린 공고 중
    # 첨부 본문이 있는 공고만 본다. 발췌 해시·추출기 버전·공고 내용 지문이 같으면 건너뛰므로 새 공고·바뀐 공고만 부른다.
    # 상한은 한국 날짜 하루 300건(같은 날 다시 돌려도 합산, data/bonus_daily_calls.json — 2026-10-06 Codex 검수 P2-6).
    # 가점·우대 말이 없는 공고는 부르지 않고 no_mention 으로 적는다. --skip-upload 도 따른다(공용 DB 쓰기)
    bonus_result = None
    if stored and not skip_bonus and not skip_upload:
        say('가점 추출')
        try:
            from collect import extract_bonus
            bonus_result = extract_bonus.run_batch(
                limit=bonus_limit if bonus_limit is not None else extract_bonus.DAILY_LIMIT,
                say=lambda line: say('  ' + line))
        except Exception as exc:
            say('  가점 추출 실패: %s' % type(exc).__name__)
            bonus_result = {'error': '%s: %s' % (type(exc).__name__, str(exc)[:200])}
    elif skip_bonus or skip_upload:
        say('가점 추출을 건너뛴다(--skip-bonus 또는 --skip-upload)')

    removed = prune('bizinfo') + prune('kstartup')
    if removed:
        say('오래된 원본 스냅샷 %d개 정리' % removed)

    # 한 소스라도 정상이 아니면 부분 실패로 본다
    degraded = [s for s, v in sources.items() if v['status'] not in ('ok', 'dry-run')]
    ok = not degraded and (stored or dry_run or skip_store)
    # 후처리 경고 — 10~14단계(LLM 추출·판정 올리기·가점)가 실패했거나 일부 호출이 실패했거나 경고를 냈다(2026-09-28 Codex 통합 검수 P2).
    # 수집 자체는 끝났으므로 status 는 그대로 둔다. 'partial' 로 바꾸면 수집 상태 판정(search/collection_status.py)이
    # 매칭을 막는다 — 공고 데이터는 새것인데 LLM 후처리만 늦은 것이라 막을 일이 아니다.
    # 대신 로그에 stage_warnings 로 남기고 종료 코드 4 로 알린다(run_daily.bat 이 run.log 에 exit=4 를 남긴다).
    stage_warnings = stage_warnings_of({'conditions': conditions_result, 'applicant_types': applicant_types_result,
                                        'industries': industries_result, 'judgments_upload': judgments_result,
                                        'bonus': bonus_result})

    return write_log({
        'status': 'ok' if ok else 'partial',
        'job': 'pipeline',
        'sources': sources,
        'degraded': degraded,
        'stage_warnings': stage_warnings,
        'normalized': os.path.basename(norm_path),
        'normalized_count': summary['accepted_count'],
        'rejected_count': summary['rejected_count'],
        'cross_source_candidate_groups': summary['cross_source_candidate_groups'],
        'stored': stored,
        'store_result': store_result,
        'attachments': attach,
        'embeddings': embed_result,
        'vector_upload': upload_result,
        'file_upload': file_result,
        'conditions': conditions_result,
        'applicant_types': applicant_types_result,
        'industries': industries_result,
        'judgments_upload': judgments_result,
        'bonus': bonus_result,
        'elapsed_sec': round(time.time() - started, 1),
    })


def stage_warnings_of(results):
    """{단계: 결과} → [{'stage', 'error'|'failed'|'warning'}]. 단계 예외·API 키 없음·일부 호출 실패·경고를 모은다.

    warning 은 2026-09-29 추가 — 13단계가 결과 파일이 크게 줄어든 것을 알리되 올리기는 막지 않을 때다.
    한 단계에 error 와 warning 이 함께 있으면 **둘 다** 남긴다(13단계는 한 표의 오류와 다른 표의 경고가 함께 날 수 있다 —
    2026-09-29 Codex 재검수 P2-2). 같은 단계가 두 줄이 될 수 있다.
    """
    out = []
    for stage, result in results.items():
        if not result:
            continue
        if result.get('error'):
            out.append({'stage': stage, 'error': result['error']})
        elif result.get('failed'):
            out.append({'stage': stage, 'failed': result['failed']})
        if result.get('warning'):
            out.append({'stage': stage, 'warning': result['warning']})
    return out


def main():
    ap = argparse.ArgumentParser(description='K-Startup + 기업마당 → 정규화 → MySQL')
    ap.add_argument('--dry-run', action='store_true', help='수집·정규화만. 교체와 DB 저장 안 함')
    ap.add_argument('--skip-store', action='store_true', help='MySQL 저장을 건너뛴다')
    ap.add_argument('--force', action='store_true', help='건수 급감 경고를 무시한다')
    ap.add_argument('--skip-attach', action='store_true', help='첨부 수집을 건너뛴다')
    ap.add_argument('--attach-limit', type=int, help='이번 실행에서 받을 첨부 상한')
    ap.add_argument('--attach-interval', type=float, default=1.0,
                    help='첨부 요청 간격(초). 기본 1.0')
    ap.add_argument('--skip-embed', action='store_true', help='임베딩을 건너뛴다')
    ap.add_argument('--embed-limit', type=int, help='이번 실행에서 만들 벡터 상한')
    ap.add_argument('--skip-upload', action='store_true',
                    help='벡터를 공용 DB 로 올리지 않는다')
    ap.add_argument('--skip-files', action='store_true',
                    help='첨부 원본 파일을 공용 DB 로 올리지 않는다')
    ap.add_argument('--skip-conditions', action='store_true',
                    help='자격요건 추출(LLM)을 건너뛴다')
    ap.add_argument('--skip-applicant-types', action='store_true',
                    help='신청자 유형 추출(LLM)을 건너뛴다')
    ap.add_argument('--skip-industries', action='store_true', help='업종 추출(LLM)을 건너뛴다')
    ap.add_argument('--industries-limit', type=int, help='이번 날짜의 업종 추출 공고 상한 (기본 300)')
    ap.add_argument('--skip-bonus', action='store_true', help='공고 가점 추출(LLM, 14단계)을 건너뛴다')
    ap.add_argument('--bonus-limit', type=int, help='가점을 추출할 공고의 한국 날짜 하루 상한 (기본 300, 같은 날 다시 돌려도 합산)')
    ap.add_argument('--skip-judgments', action='store_true',
                    help='판정(신청자 유형·업종)을 공용 DB 로 올리지 않는다')
    ap.add_argument('--applicant-types-limit', type=int,
                    help='이번 실행에서 신청자 유형을 추출할 공고 상한 (기본 300)')
    ap.add_argument('--conditions-limit', type=int,
                    help='이번 실행에서 추출할 공고 상한')
    args = ap.parse_args()

    r = run(dry_run=args.dry_run, skip_store=args.skip_store, force=args.force,
            skip_attach=args.skip_attach, attach_limit=args.attach_limit,
            attach_interval=args.attach_interval,
            skip_embed=args.skip_embed, embed_limit=args.embed_limit,
            skip_upload=args.skip_upload, skip_files=args.skip_files,
            skip_conditions=args.skip_conditions,
            conditions_limit=args.conditions_limit,
            skip_applicant_types=args.skip_applicant_types,
            applicant_types_limit=args.applicant_types_limit,
            skip_judgments=args.skip_judgments,
            skip_industries=args.skip_industries, industries_limit=args.industries_limit,
            skip_bonus=args.skip_bonus, bonus_limit=args.bonus_limit)

    if r['status'] == 'busy':
        print('이미 수집 작업이 실행 중이다.', file=sys.stderr)
        return 3
    if r['status'] == 'error':
        print('실패 — %s' % r.get('error'), file=sys.stderr)
        print('기존 데이터를 그대로 둔다.')
        return 1

    print('\n%s — 정규화 %d건 / %.1f초'
          % (r['status'], r.get('normalized_count', 0), r.get('elapsed_sec', 0)))
    for source, v in (r.get('sources') or {}).items():
        print('  %-10s %-9s %s건%s'
              % (source, v['status'], v.get('count'),
                 ' — ' + v['error'] if v.get('error') else ''))
    sr = r.get('store_result') or {}
    if sr.get('closed_missing') is not None:
        print('  %-10s 모집 중 목록에서 빠진 K-Startup %d건 → closed' % ('모집 종료', sr['closed_missing']))
    a = r.get('attachments') or {}
    if a.get('counts') or a.get('error'):
        print('  %-10s %s' % ('첨부', a.get('error') or
              ' · '.join('%s %d' % kv for kv in sorted(a['counts'].items()))))
    e = r.get('embeddings') or {}
    if e:
        idx = e.get('index') or {}
        print('  %-10s %s' % ('임베딩', e.get('error') or
              ('새로 %d건 · 색인 %d건%s'
               % (e.get('made', 0), idx.get('indexed', 0),
                  '  ⚠ 색인 누락 %d건' % idx['missing'] if idx.get('missing') else ''))))
    u = r.get('vector_upload') or {}
    if u:
        # 공고가 없어 못 올린 벡터는 조용히 넘기지 않는다. 그 공고는 검색에서 빠진다.
        print('  %-10s %s' % ('벡터 업로드', u.get('error') or
              ('올림 %d건 · DB %d건%s'
               % (u.get('uploaded', 0), u.get('remote', 0),
                  '  ⚠ 공고 없어 건너뜀 %d건' % u['skipped_no_notice']
                  if u.get('skipped_no_notice') else ''))))
    fu = r.get('file_upload') or {}
    if fu:
        print('  %-10s %s' % ('첨부 파일', fu.get('error') or
              ('올림 %d개 %.1fMB%s'
               % (fu.get('uploaded', 0), fu.get('sent_mb', 0),
                  '  ⚠ 해시 불일치 %d개' % fu['hash_mismatch']
                  if fu.get('hash_mismatch') else ''))))
    at = r.get('applicant_types') or {}
    if at:
        print('  %-10s %s' % ('신청자 유형', at.get('error') or
              ('추출 %d건 · 누적 %d건%s%s'
               % (at.get('extracted', 0), at.get('total', 0),
                  '  ⚠ 실패 %d건' % at['failed'] if at.get('failed') else '',
                  '  · 상한으로 미룸 %d건' % at['deferred'] if at.get('deferred') else ''))))
    ind = r.get('industries') or {}
    if ind:
        print('  %-10s %s' % ('업종', ind.get('error') or
              ('추출 %d건 · 누적 %d건%s%s'
               % (ind.get('extracted', 0), ind.get('total', 0),
                  '  ⚠ 실패 %d건' % ind['failed'] if ind.get('failed') else '',
                  '  · 상한으로 미룸 %d건' % ind['deferred'] if ind.get('deferred') else ''))))
    ju = r.get('judgments_upload') or {}
    if ju:
        print('  %-10s %s' % ('판정 올리기', ju.get('error') or ' · '.join(
            '%s 올림 %d' % ({'types': '유형', 'industries': '업종'}.get(k, k), v.get('uploaded', 0))
            for k, v in ju.items() if isinstance(v, dict))))
    cd = r.get('conditions') or {}
    if cd:
        print('  %-10s %s' % ('자격요건', cd.get('error') or
              ('추출 %d건 · 금액 %d · 형태 %d%s'
               % (cd.get('extracted', 0), cd.get('amount', 0), cd.get('types', 0),
                  '  ⚠ 실패 %d건' % cd['failed'] if cd.get('failed') else ''))))
    if r['status'] == 'partial':
        print('\n일부 소스가 갱신되지 않았다. 해당 소스는 직전 데이터를 유지한다.')
        return 2
    if r.get('stage_warnings'):
        print('\n수집은 끝났지만 후처리(LLM)에 경고가 있다: %s'
              % ', '.join(dict.fromkeys(w['stage'] for w in r['stage_warnings'])))
        return 4
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
